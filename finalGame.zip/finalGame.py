# Importing required libraries
import os.path
import random
import sys

# Initialize values
numSides = 0
function = ''
success = 0
glassBottle = False
message = 'tomorrow'
scrollMessage = 'Magic Healing Wounds Scroll' 
dagger = False
lifePoints = 7
maxLifePoints = 7
result = 0
roll = 0

# Function to read text files and return error if they don't load
def readTextFile(filePath):
    if os.path.isfile(filePath):
        with open(filePath, 'r') as file:
            content = file.read()
            return content
    else:
        print('The file does not exist')
        sys.exit()
        
# Dice rolling function
def diceRoll (numSides, function, success):

    roll = random.randint(1, numSides)

    if function == 'attack':
        if roll == 1:
            result = 'Critical fail'
        elif roll == 20:
            result = 'Critical hit'
        elif roll >= 12:
            result = 'Hit'
        else:
            result = 'Miss'

    elif function == 'check':
        if roll >= success:
            result = 'Success'
        else:
            result = 'Fail'
    else:
        result = ''

    return roll, result

# function for scroll usage
def useScroll(lifePoints, maxLifePoints):
    global scrollUses, scroll
    if lifePoints < maxLifePoints and scrollUses > 0 and scroll:
        heal = random.randint(1, 4)  
        potentialLifePoints = lifePoints + heal
        lifePoints = min(potentialLifePoints, maxLifePoints)  
        scrollUses -= 1
        print(f'Used scroll to heal {heal} life points. Remaining uses: {scrollUses}. Current Life Points: {lifePoints}')
    return lifePoints


#bonus room function
def crypticDepths():
    global lifePoints, maxLifePoints, glassBottle, dagger, scroll, scrollUses, result, roll
    sampleText = readTextFile('6_bonus.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)
    monsterLP = 6
    lifePoints = 7
    print(f'Current Life Points: {lifePoints}')    
    while lifePoints > 0 and monsterLP > 0:
        if lifePoints < maxLifePoints and scroll and scrollUses > 0:
            while True:  
                scrollChoice = input('Would you like to use the Magic Healing Scroll? (yes/no): ')
                scrollChoice = scrollChoice.lower()  
                if scrollChoice == 'yes':
                    lifePoints = useScroll(lifePoints, maxLifePoints)
                    print(f'After using the scroll, your life points are: {lifePoints}')
                    break 
                elif scrollChoice == 'no':
                    print('You chose not to use the scroll.')
                    break  
                else:
                    print('Invalid entry. Please enter "yes" or "no".')
        # Determine damage based on whether the player has a dagger
        if dagger:
            numSides = 6  
        else:
            numSides = 4  
        roll, result = diceRoll(20, 'attack', 0)
        if result == 'Critical hit':
            damage = random.randint(1, numSides) * 2  
        elif result == 'Hit':
            damage = random.randint(1, numSides)  
        else:
            damage = 0  
        print(f'You rolled {roll} - {result}.')
        if dagger and (result == 'Critical hit' or result == 'Hit'):
            print(f'You attacked with the dagger and dealt {damage} damage ')
        else:
            print(f'You dealt {damage} damage to Sirius the Snake.')
        monsterLP -= damage

        if monsterLP <= 0:
            print('You defeated Sirius the Snake!')
            print('You can now explore the room.')
            print('You found a glass bottle with a message inside!')
            glassBottle = True
            break

        input('Press Enter to continue...')

        # Monster's turn
        roll, result = diceRoll(20, 'attack', 0)
        if result == 'Critical hit':
            damage = random.randint(1, 4) * 2
        elif result == 'Hit':
            damage = random.randint(1, 4)
        else:
            damage = 0

        print(f'Sirius the Snake attacks! It rolled {roll} - {result}.')
        print(f'Sirius the Snake dealt {damage} damage to you.')
        lifePoints -= damage

        if lifePoints <= 0:
            print('You were defeated by Sirius the Snake.')
            while True:
                choice = input('Would you like to restart the game? (yes/no): ')
                if choice.lower() in ['yes', 'no']:
                    break
                print('Invalid input. Please enter "yes" or "no".')
            if choice.lower() == 'yes':
                Library()
            else:
                print('Game over.')
                sys.exit()

        input('Press Enter to continue...')

    while True:
        choice = input('Would you like to return to the library? (yes/no): ')
        if choice.lower() in ['yes', 'no']:
            break
        print('Invalid input. Please enter "yes" or "no".')
    if choice.lower() == 'yes':
        Library()
    else:
        print('Game over.')

    while True:
        choice = input('Would you like to restart the game? (yes/no): ')
        if choice.lower() in ['yes', 'no']:
            break
        print('Invalid input. Please enter "yes" or "no".')
    if choice.lower() == 'yes':
        Library()
    else:
        sys.exit()

# workshop function
def workshop():
    sampleText = readTextFile('2_workshop.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)
    print('Options:', '(1) Search the workshop', '(2) Go through the north door', '(3) Return to the library')

    validChoices = [1, 2, 3]
    while True:
        choice = input('Enter your choice: ')
        try:
            choice = int(choice)
            if choice in validChoices:
                break
            else:
                print('Try again. Please enter either 1, 2, or 3.')
        except ValueError:
            print('Try again. Please enter a valid choice')

    if choice == 1:
        global dagger
        print('You chose to search the workshop.')
        print('You found a dagger and some gold.')
        dagger = True
        print('Options after searching:', '(1) Go through the north door', '(2) Return to the library')

        validChoices = [1, 2]
        while True:
            choice = input('Enter your choice: ')
            try:
                choice = int(choice)
                if choice in validChoices:
                    break
                else:
                    print('Try again. Please enter either 1 or 2.')
            except ValueError:
                print('Try again. Please enter a valid choice')
                
        if choice == 1:
            print('You chose to go through the north door.')
            wellRoom()
        elif choice == 2:
            print('You chose to return to the library.')
            Library()

    elif choice == 2:
        print('You chose to go through the north door.')
        wellRoom()

    elif choice == 3:
        print('You chose to return to the library.')
        Library()

    return
def roomChoice():
    validChoices = [1, 2, 3]
    while True:
        choice = input('Enter your choice: ')
        try:
            choice = int(choice)
            if choice in validChoices:
                return choice
            else:
                print('Try again. Please enter either 1, 2, or 3.')
        except ValueError:
            print('Try again. Please enter a valid number')
        if choice == 2:
            print('You chose to go through the west door')
            wellRoom()
        elif choice == 3:
            print('You chose to return to the library')
            Library()

#empty room function
def emptyRoom():
    sampleText = readTextFile('3_empty.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)
    print('Options:', '(1) Search the empty room', '(2) Go through the west door', '(3) Return to the library')

    choice = roomChoice()

    if choice == 1:
        print('You chose to search the empty room.')
        roll, result = diceRoll(20, 'check', 12)
        if result == 'Success':
            print('You found a trap in the room and avoided it.')
            print('Options after searching:', '(1) Go through the west door', '(2) Return to the library')
            choice = roomChoice()
            if choice == 1:
                print('You chose to go through the west door safely.')
                wellRoom()
            elif choice == 2:
                print('You chose to return to the library safely.')
                Library()
        else:
            print('You search the room but find nothing of interest.')
            print('Options:', '(2) Go through the west door', '(3) Return to the library')
            choice = roomChoice()
    if choice == 2:
            unsearchedChoice(choice)
    elif choice == 3:
            print('You chose to return to the library')
            Library()
            
def unsearchedChoice(choice):
    global lifePoints, maxLifePoints, scroll, scrollUses
    maxLifePoints = 7  # Assuming this is constant and set globally
    
    if choice == 2:
        print('You chose to go through the west door.')
        print('As you open the door, you fall into a trap.')
        roll, _ = diceRoll(6, '', 0)
        lifePoints -= roll
        print(f'Current Life Points: {lifePoints}')
        print(f'You lose {roll} life points.')

        if lifePoints <= 0:
            print('You died from your wounds.')
            sys.exit()  # Exit the program as the player has died

        if lifePoints > 0 and lifePoints < maxLifePoints and scroll and scrollUses > 0:
            scrollChoice = input('Would you like to use the Magic Healing Scroll? (yes/no): ')
            if scrollChoice.lower() == 'yes':
                lifePoints = useScroll(lifePoints, maxLifePoints)
                print(f'You used the scroll. Current Life Points: {lifePoints}')

            elif scrollChoice.lower() == 'no':
                print('You chose not to use the scroll.')
            else:
                print('Invalid input. Please enter "yes" or "no".')
        else:
            if lifePoints <= 0:
                print('You died from your wounds.')
                sys.exit()

        wellRoom()  # Ensure this function is defined elsewhere in your code

    elif choice == 3:
        print('You chose to return to the library.')
        Library()


#well room function
def wellRoom():
    global glassBottle

    # Reading and displaying texts
    sampleText = readTextFile('4_well.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)
    print('The door has been locked!')
    sampleText = readTextFile('5_foshi.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)

    # Appearance of Foshi and illusion
    intelligenceRoll = random.randint(1, 20)
    print('You roll a:', intelligenceRoll)
    if intelligenceRoll >= 18:
        print('You realized that Foshi is an illusion!')
    else:
        print('You have merged with Foshi!')

    # Ask if the player wants to attack Foshi
    while True:
        attackChoice = input('Would you like to attack Foshi? (yes/no): ')
        if attackChoice.lower() == 'yes':
            print('You attempt to attack Foshi...')
            attack_roll = diceRoll(20, 'attack', 21)
            roll, result = attack_roll
            print('Attack roll:', roll)
            print('You missed.')
            break
        elif attackChoice.lower() == 'no':
            print('You choose not to attack Foshi.')
            break
        else:
            print('Invalid choice. Please enter either "yes" or "no".')

    # Ask if the player wants to use the glassBottle
    if glassBottle:  
        while True:
            choice = input('Would you like to open the glass bottle you found in the Cryptic Depths? (yes/no): ')
            if choice.lower() == 'yes':
                print('The message inside reads: "Tomorrow".')
                break
            elif choice.lower() == 'no':
                print('You chose not to open the glass bottle.')
                break
            else:
                print('Invalid choice. Please enter either "yes" or "no".')

    # riddle for loop
    correctAnswers = ['tomorrow', 'Tomorrow', 'TOMORROW']
    attempts = 3
    for attempt in range(1, attempts + 1):
        riddleAnswer = input('What is the answer to Foshi\'s riddle?: ')
        if riddleAnswer in correctAnswers:
            print('Congratulations! You solved the riddle!')
            print('You have been awarded Foshi\'s Book of Wonders.')
            while True:
                playAgain = input('Congratulations! Would you like to play again? (yes/no): ')
                if playAgain.lower() == 'yes':
                    Library() 
                elif playAgain.lower() == 'no':
                    print('Goodbye!')
                    sys.exit() 
                else:
                    print('Invalid input. Please answer with "yes" or "no".')
            break 
        else:
            remainingAttempts = attempts - attempt
            if remainingAttempts > 0:
                print(f'Incorrect answer. You have {remainingAttempts} attempt(s) remaining.')
            else:
                print('You have run out of attempts. The illusion of Foshi fades away.')
                print('You have lost the game.')
                while True:
                    playAgain = input('Would you like to play again? (yes/no): ')
                    if playAgain.lower() == 'yes':
                        Library() 
                    elif playAgain.lower() == 'no':
                        print('Goodbye!')
                        sys.exit()  
                    else:
                        print('Invalid input. Please answer with "yes" or "no".')

#library function
def Library():
    global scroll, scrollUses
    scroll = False
    sampleText = readTextFile('0_intro.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)
    sampleText = readTextFile('1_library.txt')
    revisedText = sampleText.replace('.', '.\n')
    print(revisedText)
    print('Options:', '(1) Search the room', '(2) Go through the north door', '(3) Go through the west door', '(4) Go down the stairs')

    validChoices = [1, 2, 3, 4]
    while True:
        choice = input('Enter your choice: ')
        try:
            choice = int(choice)
            if choice in validChoices:
                break
            else:
                print('Try again. Please enter a valid choice.')
        except ValueError:
            print('Try again. Please enter a valid choice')

    if choice == 1:
        print('You chose to search the room.')
        perceptionCheck = diceRoll(20, 'check', 12)
        roll, result = perceptionCheck
        if result == 'Success':
            print(f'You found the {scrollMessage}')
            scrollUses = diceRoll(10, '', 0)[0]
            print('The scroll can be used', scrollUses, 'times.')
            scroll = True
            print('Options:', '(2) Go through the north door', '(3) Go through the west door', '(4) Go down the stairs')
            validChoices = [2, 3, 4]
            while True:
                choice = input('Enter your choice: ')
                try:
                    choice = int(choice)
                    if choice in validChoices:
                        break
                    else:
                        print('Try again. Please enter 2, 3, or 4.')
                except ValueError:
                    print('Try again. Please enter a valid choice')

            if choice == 2:
                print('You chose to go through the north door.')
                emptyRoom()

            elif choice == 3:
                print('You chose to go through the west door.')
                workshop()

            elif choice == 4:
                print('You chose to go down the stairs.')
                crypticDepths()

            return
        else:
            print('You search the room but find nothing of interest.')
            print('Options:', '(2) Go through the north door', '(3) Go through the west door', '(4) Go down the stairs')

            validChoices = [2, 3, 4]
            while True:
                choice = input('Enter your choice: ')
                try:
                    choice = int(choice)
                    if choice in validChoices:
                        break
                    else:
                        print('Try again. Please enter 2, 3, or 4.')
                except ValueError:
                    print('Try again. Please enter a valid choice')

            if choice == 2:
                print('You chose to go through the north door.')
                emptyRoom()

            elif choice == 3:
                print('You chose to go through the west door.')
                workshop()

            elif choice == 4:
                print('You chose to go down the stairs.')
                crypticDepths()

            return

    elif choice == 2:
        print('You chose to go through the north door.')
        emptyRoom()

    elif choice == 3:
        print('You chose to go through the west door.')
        workshop()

    elif choice == 4:
        print('You chose to go down the stairs.')
        crypticDepths()
        
Library()
